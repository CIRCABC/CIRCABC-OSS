/**
 * Copyright (C) 2005-2013 Alfresco Software Limited.
 *
 * This file is part of Alfresco
 *
 * Alfresco is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Alfresco is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Alfresco. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * @module alfresco/services/LoggingService
 * @extends module:alfresco/core/Core
 * @mixes module:alfresco/services/_PreferenceServiceTopicMixin
 * @author Dave Draper
 */
define(["dojo/_base/declare",
        "alfresco/core/Core",
        "alfresco/services/_PreferenceServiceTopicMixin",
        "dojo/_base/lang",
        "dojo/sniff",
        "dijit/registry",
        "alfresco/dialogs/AlfDialog",
        "alfresco/buttons/AlfButton"],
        function(declare, AlfCore, _PreferenceServiceTopicMixin, lang, has, registry, AlfDialog, AlfButton) {
   
   return declare([AlfCore, _PreferenceServiceTopicMixin], {
      
      /**
       * An array of the i18n files to use with this widget.
       * 
       * @instance
       * @type {{i18nFile: string}[]}
       * @default [{i18nFile: "./i18n/LoggingService.properties"}]
       */
      i18nRequirements: [{i18nFile: "./i18n/LoggingService.properties"}],
      
      /**
       * @instance
       * @type {string}
       * @default "org.alfresco.share.logging"
       */
      loggingPreferencesId: "org.alfresco.share.logging",
      
      /**
       * This will hold a reference to the subscription to log events. It will be null unless logging is enabled. 
       * 
       * @instance
       * @type {object}
       * @default null
       */
      logSubscriptionHandle: null,
      
      /**
       * Sets up the subscriptions for the LoggingService
       * 
       * @instance
       * @param {array} args The constructor arguments.
       */
      constructor: function alfresco_services_LoggingService__constructor(args) {
         this.alfSubscribe("ALF_LOGGING_STATUS_CHANGE", lang.hitch(this, "onLoggingStatusChange"));
         this.alfSubscribe("ALF_UPDATE_LOGGING_PREFERENCES", lang.hitch(this, "onDetailsDialog"));
         
         this.alfPublish(this.getPreferenceTopic, {
            preference: this.loggingPreferencesId,
            callback: this.setLoggingStatus,
            callbackScope: this
         });
      },
      
      /**
       * Handles requests to change the current logging status.
       * 
       * @instance
       * @param {object} payload
       */
      onLoggingStatusChange: function alfresco_services_LoggingService__onLoggingStatusChange(payload) {
         if (lang.exists("selected", payload) && lang.exists("value", payload))
         {
            this.alfPublish(this.setPreferenceTopic, {
               preference: this.loggingPreferencesId + "." + payload.value,
               value: (payload.selected == true)
            });
            this.loggingPreferences[payload.value] = (payload.selected == true);
            this.handleSubscription();
         }
      },
      
      /**
       * @instance
       * @param {boolean} value Indicates whether or not to enable or disable logging.
       */
      setLoggingStatus: function alfresco_services_LoggingService__setLoggingStatus(value) {
         if (value == null)
         {
            value = {};
         }
         this.loggingPreferences = value;
         this.handleSubscription();
      },
      
      /**
       * Updates the subscription to the logging topic
       * 
       * @instance
       */
      handleSubscription: function alfresco_services_LoggingService__handleSubscription() {
         if (this.loggingPreferences.enabled && this.logSubscriptionHandle == null)
         {
            this.logSubscriptionHandle = this.alfSubscribe(this.alfLoggingTopic, lang.hitch(this, "onLogRequest"));
         }
         else if (!this.loggingPreferences.enabled && this.logSubscriptionHandle != null)
         {
            this.alfUnsubscribe(this.logSubscriptionHandle);
            this.logSubscriptionHandle = null;
         }
      },
      
      /**
       * This attribute is used to hold a reference to a [dialog]{@link module:alfresco/dialogs/AlfDialog} that can be
       * used to set more granular logging information (e.g. wildcard style matches for widgets and functions). It is set
       * on the first call to the [onDetailsDialog function]{@link module:alfresco/services/LoggingService#onDetailsDialog}.
       * 
       * @instance
       * @type {object}
       * @default null
       */
      detailsDialog: null,
      
      /**
       * This is the topic used to subscribe to requests to save logging preferences updated by the 
       * [preferences dialog]{@link module:alfresco/services/LoggingService#detailsDialog}.
       * 
       * @instance
       * @type {string}
       * @default "ALF_SAVE_LOGGING_PREFERNCES_UPDATE"
       */
      saveLoggingPrefsUpdateTopic: "ALF_SAVE_LOGGING_PREFERNCES_UPDATE",
      
      /**
       * This is the topic used to subscribe to requests to cancel logging preferences updates set in the 
       * [preferences dialog]{@link module:alfresco/services/LoggingService#detailsDialog}.
       * 
       * @instance
       * @type {string}
       * @default "ALF_CANCEL_LOGGING_PREFERNCES_UPDATE"
       */
      cancelLoggingPrefsUpdateTopic: "ALF_CANCEL_LOGGING_PREFERNCES_UPDATE",
      
      /**
       * @instance
       * @param {object} payload
       */
      onDetailsDialog: function alfresco_services_LoggingService__onDetailsDialog(payload) {
         if (this.detailsDialog == null)
         {
            this.alfSubscribe(this.saveLoggingPrefsUpdateTopic, lang.hitch(this, "onPrefsUpdateSave"));
            this.alfSubscribe(this.cancelLoggingPrefsUpdateTopic, lang.hitch(this, "onPrefsUpdateCancel"));
            this.detailsDialog = new AlfDialog({
               title: this.message("logging.preferences.title"),
               widgetsContent: [
                  {
                     name: "alfresco/forms/controls/DojoValidationTextBox",
                     config: {
                        id: this.id + "_LOGGING_FILTER",
                        name: "filter",
                        label: this.message("filter.label"),
                        description: this.message("filter.description"),
                        value: (this.loggingPreferences.filter != null) ? this.loggingPreferences.filter : ""
                     }
                  }
               ],
               widgetsButtons: [
                  {
                     name: "alfresco/buttons/AlfButton",
                     config: {
                        label: this.message("button.save-logging-prefs"),
                        publishTopic: this.saveLoggingPrefsUpdateTopic,
                        publishPayload: payload
                     }
                  },
                  {
                     name: "alfresco/buttons/AlfButton",
                     config: {
                        label: this.message("button.cancel-logging-prefs-update"),
                        publishTopic: this.cancelLoggingPrefsUpdateTopic,
                        publishPayload: payload
                     }
                  }
               ]
            });
         }
         this.detailsDialog.show();
      },
      
      /**
       * @instance
       * @param {object} payload
       */
      onPrefsUpdateSave: function alfresco_services_LoggingService__onPrefsUpdateSave(payload) {
         var filterWidget = registry.byId(this.id + "_LOGGING_FILTER");
         if (filterWidget != null)
         {
            var filterValue = filterWidget.getValue();
            this.alfPublish(this.setPreferenceTopic, {
               preference: this.loggingPreferencesId + ".filter",
               value: filterValue
            });
            this.loggingPreferences.filter = filterValue;
         }
      },
      
      /**
       * @instance
       * @param {object} payload
       */
      onPrefsUpdateCancel: function alfresco_services_LoggingService__onPrefsUpdateCancel(payload) {
         var filterWidget = registry.byId(this.id + "_LOGGING_FILTER");
         if (filterWidget != null)
         {
            var filterValue = filterWidget.setValue((this.loggingPreferences.filter != null) ? this.loggingPreferences.filter : "");
         }
      },
      
      /**
       * The local copy of logging preferences.
       * 
       * @instance
       * @type {object}
       * @default null
       */
      loggingPreferences: null,
      
      /**
       * @instance
       * @param {{severity: string, callerName: string, messageArgs: object[]} payload
       */
      onLogRequest: function alfresco_services_LoggingService__onLogRequest(payload) {
         if (payload &&
             payload.severity &&
             payload.messageArgs && 
             (this.loggingPreferences.all == true ||
              this.loggingPreferences[payload.severity] == true))
         {
            if (typeof console[payload.severity] != "function" && (!has("ie") > 9))
            {
               // Catch developer errors !!
               console.error("The supplied severity is not a function of console", payload.severity);
            }
            else
            {
               // Call the console method passing all the additional arguments)...
               var callerName = payload.callerName;
               if (callerName && callerName != "")
               {
                  var fIndex = callerName.lastIndexOf("__"),
                      re1 = /([^_])(_){1}/g;
                  if (fIndex != -1)
                  {
                     var mName = callerName.substring(0, fIndex);
                     var fName = callerName.substring(fIndex + 2);
                     callerName = mName.replace(re1, "$1/") + "[" + fName + "] >> ";
                  }
                  else
                  {
                     callerName = callerName + " >> ";
                  }
               }
               else
               {
                  callerName = "";
               }
               
               // Check to see whether or not there is a log filter and if so, whether or 
               // not the current caller passes the filter...
               var matchesFilter = true;
               if (this.loggingPreferences.filter != null)
               {
                  var test = new RegExp(this.loggingPreferences.filter);
                  matchesFilter = test.test(callerName);
               }
               
               // If the filter is mapped (or if there is no filter) output the log...
               if (matchesFilter)
               {
                  payload.messageArgs[0] = callerName + payload.messageArgs[0];
                  if (has("ie") <= 9)
                  {
                     if (payload.severity == "error")
                     {
                        console.error(payload.messageArgs);
                     }
                     else
                     {
                        console.log(payload.messageArgs);
                     }
                  }
                  else
                  {
                     console[payload.severity].apply(console, payload.messageArgs);
                  }
               }
            }
         }
      }
   });
});
