/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package demo.client;

import java.net.InetAddress;
import java.net.UnknownHostException;
import javax.xml.namespace.QName;
import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBusFactory;
import org.apache.cxf.jaxws.ServiceImpl;

/**
 * validate call to ejb in jboss from command line
 */
public final class GreeterClient {

    protected GreeterClient() {
    }

    public static void main(String[] args) throws Exception {
        Bus bus = new SpringBusFactory().getDefaultBus();
        QName serviceQName = new QName("http://apache.org/hello_world_soap_http", "Greeter");
        QName portQName = new QName("http://apache.org/hello_world_soap_http", "HelloPort");
        String bindingId = "http://schemas.xmlsoap.org/soap/";

        String hostName = "";
        try {
            InetAddress addr = InetAddress.getLocalHost();
            //hostName = addr.getHostName();
            hostName = addr.getCanonicalHostName();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        
        String address = "http://" + hostName + ":9999/GreeterBean";

        ServiceImpl ss = new ServiceImpl(bus, null, serviceQName, null);
        ss.addPort(portQName, bindingId, address);
        //Hello port = ss.createPort(portQName, Hello.class);
        org.apache.hello_world_soap_http.Greeter port = ss.getPort(portQName, 
            org.apache.hello_world_soap_http.Greeter.class);
        String response = port.greetMe(" CXF");
        System.out.println(" server return: " + response);
    }
}
