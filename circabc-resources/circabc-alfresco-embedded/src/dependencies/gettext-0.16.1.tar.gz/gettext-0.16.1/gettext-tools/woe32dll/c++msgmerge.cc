#include "../src/msgmerge.c"
