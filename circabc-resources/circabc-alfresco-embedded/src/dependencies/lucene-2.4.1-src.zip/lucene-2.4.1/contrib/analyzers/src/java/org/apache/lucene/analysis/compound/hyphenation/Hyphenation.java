/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.analysis.compound.hyphenation;

/**
 * This class represents a hyphenated word.
 * 
 * This class has been taken from the Apache FOP project (http://xmlgraphics.apache.org/fop/). They have been slightly modified.
 */
public class Hyphenation {

  private int[] hyphenPoints;

  /**
   * number of hyphenation points in word
   */
  private int len;

  /**
   * rawWord as made of alternating strings and {@link Hyphen Hyphen} instances
   */
  Hyphenation(int[] points) {
    hyphenPoints = points;
  }

  /**
   * @return the number of hyphenation points in the word
   */
  public int length() {
    return hyphenPoints.length;
  }

  /**
   * @return the hyphenation points
   */
  public int[] getHyphenationPoints() {
    return hyphenPoints;
  }
}
